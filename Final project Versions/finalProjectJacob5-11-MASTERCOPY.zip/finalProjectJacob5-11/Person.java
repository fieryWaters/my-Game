
/**
 * Write a description of class Person here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Person
{
    private String name;
    private String position;
    public boolean[][] schedule = new boolean[7][48];//days halfHours

    public Person(String name,String position)
    {
        this.name=name;
        this.position=position;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getPosition()
    {
        return position;
    }

    public void setPosition(String position)
    {
        this.position = position;
    }

    public void viewSchedule()
    {
        for(int day=0;day<7;day++)
        {
            for(int halfHour=0;halfHour<48;halfHour++)
            {
                if(halfHour%2==0)

                    System.out.print((halfHour/2)+":00 ");
                else
                    System.out.print((halfHour/2)+":30 ");
                System.out.print(schedule[day][halfHour]);
                System.out.println();
            }
        }
    }
}
