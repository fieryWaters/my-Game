 

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Iterator;
/**
 * Write a description of class Driver here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Driver
{
    public static Schedule globalSchedule;
    public static void main()
    {
        boolean admin;
        boolean done=false;
        Scanner scan=new Scanner(System.in);
        System.out.println("Admin or user?");
        String[] correctAnswers={"Admin","User"};
        String answer=findValidAnswer(correctAnswers, scan);
        globalSchedule=new Schedule();
        if(answer.equalsIgnoreCase("Admin"))
            admin=true;
        else
            admin=false;
        if(admin)
        {
            do{
                System.out.println("Ok, big guy, what would you like to do?");
                System.out.println("Enter the number that correspronds with your choice.");
                System.out.println("1: add a new job title.");
                System.out.println("2: change the Schedule.");
                System.out.println("3: quit the program.");

                String[] oneTwoThree={"1","2","3"};
                answer=findValidAnswer(oneTwoThree,scan);
                int choice=Integer.parseInt(answer);
                if(choice==1)
                {
                    do
                    {
                        String newPosition;
                        do
                        {
                            System.out.println("What is the position you'd like to add?");
                            newPosition=scan.nextLine();
                            System.out.println("Is this spelled correctly: "+newPosition);
                            correctAnswers[0]="yes";correctAnswers[1]="no";
                            answer=findValidAnswer(correctAnswers,scan);
                        }while(!answer.equals("yes"));
                        globalSchedule.addPosition(newPosition);
                        System.out.println("are you done?");
                        answer=findValidAnswer(correctAnswers,scan);
                        done=answer.equals("yes");
                    }while(!done);
                    done=false;
                }
                else if(choice==2)
                {
                    String[] days={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
                    System.out.println("Alrighty then, would you like to start from the beginning?");
                    correctAnswers[0]="yes";correctAnswers[1]="no";
                    answer=findValidAnswer(correctAnswers,scan);
                    done=false;
                    if(answer.equals("yes"))
                    {
                        for(int week=0;!done;week++)
                        {
                            for(int day=0;day<7;day++)
                            {
                                do
                                {
                                    if(addPeople(week,day,scan))
                                    {
                                        globalSchedule.printSchedule(week,day);
                                        System.out.println("add successful, you can say \"1\" continue with today, \"2\" go to tomorrow, \"3\" next Week, or \"4\" I'm over it yo");
                                        String[] oneTwoThreeFour={"1","2","3","4"};
                                        answer=findValidAnswer(oneTwoThreeFour,scan);
                                        if(answer.equals("2"))
                                            done=true;
                                        else if(answer.equals("3"))
                                        {
                                            week++;
                                            day=0;
                                        }else if(answer.equals("4"))
                                        {
                                            done=true;day=7;
                                        }
                                        globalSchedule.printSchedule(week,day);
                                    }
                                    else
                                    {
                                        System.out.println("Would you like to try again?");
                                        answer=findValidAnswer(correctAnswers,scan);
                                        if(answer.equals("no"))
                                            done=true;
                                    }
                                }while(!done);
                            }
                            System.out.println("wow, you actually went through a whole week, you must be a thorough cucumber, truly.");
                            System.out.println("Are you done, I doubt you want to do that a second time.");
                            String[] yesNo={"yes","no"};
                            answer=findValidAnswer(yesNo,scan);
                            if(answer.equals("yes"))
                            done=true;
                        }
                        done=false;
                    }
                    else
                    {

                    }
                }else
                {
                    done=true;
                }
            }while(!done);
        }
    }

    public static boolean addPeople(int week,int day,Scanner scan)// 3 Busser 7:30-13:30
    {
        String[] correctAnswers={"yes","no"};
        String answer;
        String[] days={"Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"};
        System.out.println("week "+(week+1)+", "+days[day]);
        System.out.println("format: numberNeeded Position StartTime-StopTime");
        System.out.println("Ex: 3 Busser 7:30-13:30");
        String argument=scan.nextLine();
        String[] peices=argument.split(" ");
        String position;
        if(globalSchedule.need[0][0][0].contains(peices[1]))
        {
            position=peices[1];
        }
        else
        {
            System.out.println("the position "+peices[1]+" is not found within the system, would you like to add "+peices[1]);
            if(findValidAnswer(correctAnswers,scan).equals("yes"))
            {
                globalSchedule.addPosition(peices[1]);
                position=peices[1];
            }else
                return false;
        }
        if(peices.length!=3)
        {
            System.out.println("there are the correct number of tokens, there should be 3, there's actually only "+peices.length);
            return false;
        }
        String[] process=peices[2].split("-");
        if(process.length!=2)
        {
            System.out.println("Time not formatted corectly, there is no - character.");
            return false;
        }
        String[] left=process[0].split(":");
        String[] right=process[1].split(":");
        if(left.length!=2||right.length!=2)
        {
            System.out.println("Time not formatted corectly, there is no : character int the time.");
            return false;
        }
        if(!(isDigit(left[0])&&isDigit(left[1])&isDigit(right[0])&&isDigit(right[1])&&isDigit(peices[0])))
        {
            System.out.println("The tokens are not digits where they should be.");
            return false;
        }
        int start=Integer.parseInt(left[0])*2;
        if(left[1].equals("30"))
        {
            start+=1;
        }else if(!left[1].equals("00"))
        {
            System.out.println("improper time format, only 30 minute increments supported.");
            return false;
        }

        int numberNeeded=Integer.parseInt(peices[0]);
        int stop=Integer.parseInt(right[0])*2;
        if(right[1].equals("30"))
        {
            stop+=1;
        }else if(!right[1].equals("00"))
        {
            System.out.println("improper time format, only 30 minute increments supported.");
            return false;
        }
        System.out.println(position+" week "+week+", day "+day+" StartTime: "+start+", stopTime "+stop+", numberNeeded "+numberNeeded);
        globalSchedule.setNeededEmployees(position,week,day,start,stop,numberNeeded);
        return true;
    }

    public static String findValidAnswer(String[] correctAnswers,Scanner scan)
    {
        String answer=scan.nextLine();
        while(!validAnswer(correctAnswers,answer))
        {
            System.out.println("Ya screwed up, bub. Try again...");
            System.out.print("you can answer : ");
            for(int i=0;i<correctAnswers.length;i++)
            {
                System.out.print(correctAnswers[i]+", ");
            }
            System.out.println("try again please.");

            answer=scan.nextLine();
        }
        return answer.toLowerCase();
    }

    public static boolean validAnswer(String[] correctAnswers,String answer)
    {
        for(String str:correctAnswers)
        {
            if(answer.equalsIgnoreCase(str))
                return true;
        }
        return false;
    }

    public static void p(String s)
    {
        System.out.println(s);
    }

    public static boolean isDigit(String str)
    {

        for(int i=0;i<str.length();i++)
        {
            if(!(Character.isDigit(str.charAt(i))))
            {
                return false;
            }
        }
        return true;
    }

}
