 

import java.util.Dictionary;
/**
 * I'm thinking that we should change have & need to a HaveDictionary[] & a NeedDictionary[]
 * so we can keep track of each time slot.
 * Also perhaps we should make a business object which keeps track of the schedule, and hold the employees in one place.
 */
import java.util.Iterator;
public class Schedule
{
    public HaveDictionary have[][][] = new HaveDictionary[4][7][48];
    public NeedDictionary need[][][] = new NeedDictionary[4][7][48];

    /**
     * Jacob Waters
     * Constructor for objects of class Schedule
     */
    public Schedule()
    {
        for(int a=0;a<have.length;a++)
            for(int b=0;b<have[0].length;b++)
                for(int c=0;c<have[0][0].length;c++)
                {
                    have[a][b][c]=new HaveDictionary();
                    need[a][b][c]=new NeedDictionary();
                }
    }

    /**
     * Jacob Waters
     */
    public void addPosition(String newPosition)
    {
        for(int a=0;a<have.length;a++)
            for(int b=0;b<have[0].length;b++)
                for(int c=0;c<have[0][0].length;c++)
                {
                    need[a][b][c].add(newPosition,0);
                }
    }

    /**
     * Jacob Waters
     */
    public void setNeededEmployees(String position,int week,int day,int startTime,int stopTime, int neededEmployees)
    {
        while(startTime<stopTime)
        {
            need[week][day][startTime].add(position,neededEmployees);
            startTime++;
        }
    }

    public void printSchedule(int week,int day)
    {
        for(int hour=0;hour<48;hour++)
        {
            Iterator positions=need[week][day][hour].getKeyIterator();
            Iterator totalNeeded=need[week][day][hour].getValueIterator();
            if(hour%2==0)

                System.out.print((hour/2)+":00 ");
            else
                System.out.print((hour/2)+":30 ");
            while(positions.hasNext())
            {
                System.out.print(totalNeeded.next()+" "+positions.next()+", ");
            }
            System.out.println();
        }
    }

}
